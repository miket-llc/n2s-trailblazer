# Adapters for external systems
