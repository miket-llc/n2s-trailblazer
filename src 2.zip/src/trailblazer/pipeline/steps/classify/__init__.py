# Classify phase modules
