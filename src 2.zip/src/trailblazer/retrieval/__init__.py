"""Retrieval module for querying embedded chunks."""
