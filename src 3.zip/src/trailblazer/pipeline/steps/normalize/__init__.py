# Normalize phase modules
