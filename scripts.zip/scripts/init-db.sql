-- Initialize pgvector extension
CREATE EXTENSION IF NOT EXISTS vector;

-- Ensure the database and user are properly configured
-- This file is run during database initialization
