# Embed phase modules
